/* KallistiOS ##version##

   seekdir.c
   Copyright (C)2004 Dan Potter

*/

#include <kos/dbglog.h>

// This isn't properly prototyped... sosume :)
void seekdir() {
    dbglog(DBG_WARNING, "seekdir: call ignored\n");
}
