/* KallistiOS ##version##

   init_defaults.c
   (c)2002 Dan Potter
*/

#include <arch/arch.h>

/* Default values which will be used if the user doesn't declare anything */
KOS_INIT_FLAGS(INIT_DEFAULT);

