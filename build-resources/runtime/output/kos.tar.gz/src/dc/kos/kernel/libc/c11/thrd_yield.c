/* KallistiOS ##version##

   thrd_yield.c
   Copyright (C) 2014 Lawrence Sebald
*/

#include <threads.h>

void thrd_yield(void) {
    thd_pass();
}
