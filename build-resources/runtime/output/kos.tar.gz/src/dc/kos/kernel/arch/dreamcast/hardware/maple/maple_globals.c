/* KallistiOS ##version##

   maple_globals.c
   (c)2002 Dan Potter
 */

#include <dc/maple.h>

/* Global state info */
maple_state_t   maple_state;

